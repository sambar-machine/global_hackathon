from flask import Flask
from flask_mysqldb import MySQL
from flask_cors import CORS
from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
llm = OpenAI(api_key=API_KEY)

app = Flask(__name__)
cors = CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Abhinav@1902'
app.config['MYSQL_DB'] = 'flask_example'

mysql = MySQL(app)

user_message_toc_temp = """
Generate an ebook for the topic '{topic}'
1. Introduction to {topic}
.
.
.
10. Conclusion
fill in the dots with the appropriate TOC with appropriate name, make sure to append these names with the title for proper content generation, make sure to follow the format of the provided TOC and do not generate the heading 'Table of Contents' or any other content apart from TOC
"""

user_message_title_temp = """
Generate an appropriate title of the ebook for the topic '{topic}'
Keep the title crisp and to the point
"""

user_message_content_temp = """
    generate content for this topic '{topic}' in markdown format.
    Note that this content will go into an ebook, so make sure it is relevant and informative and complete within specified tokens only.
    You are free to use any resources available on the internet to generate the content.
    But you are not allowed to provide incomplete information.
    Do not include the heading 'Table of Contents' or any other content apart from the content for the topic.
"""


def return_response(user_message_temp, pass_content, max_tokens=500, temperature=0.15):
    return llm.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an AI ebook generator, assisting users in creating ebooks."},
            {"role": "user", "content": user_message_temp.format(
                topic=pass_content)},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=1,
    )


@app.route('/get_response/<prompt>')
def get_response(prompt):
    title = return_response(user_message_title_temp,
                            prompt, 50, 1).choices[0].message.content
    toc = return_response(user_message_toc_temp, prompt,
                          150).choices[0].message.content

    cursor = mysql.connection.cursor()
    cursor.execute('INSERT INTO toc(title, toc) VALUES(%s, %s)', (title, toc))
    mysql.connection.commit()
    cursor.close()

    lines = toc.split("\n") 

    html_content = f"<h1 style='color: #3366BB; text-align: center;'>{title}</h1>\n"
    html_content += "<h2 style='text-align: center;'>Table of Contents</h2>\n"
    html_content += "<ul style='list-style: none; margin-top: 16px;'>\n"
    for line in lines:
        if line != "":
            html_content += f"  <li style='font-size: 20px; text-decoration: none;'>{line}</li>\n"
    html_content += '</ul>\n'
    return html_content


@app.route('/get/<title>/<num>')
def get_page(title, num):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT toc from toc WHERE title=%s", (title,))
    toc = cursor.fetchone()[0]
    cursor.close()

    lines = toc.split("\n")

    content = return_response(
        user_message_content_temp, lines[int(num) - 1], 500).choices[0].message.content
    cursor = mysql.connection.cursor()
    cursor.execute(
        'INSERT INTO content(title, content) VALUES(%s, %s)', (title, content))
    mysql.connection.commit()
    cursor.close()
    return content


@app.route('/edit/<prompt>/<title>/<changes>', methods=['patch'])
def edit_page(prompt, title, changes):
    # get prompt from db and generate new content for that title with changes
    # update content in db and return new content
    return prompt + title + changes


@app.route('/generate_pdf/<prompt>')
def generate_pdf(prompt):
    # get toc and contents from db generate pdf and store in s3
    # return pdf url
    return "pdf"


app.run(port=3300, debug=True)