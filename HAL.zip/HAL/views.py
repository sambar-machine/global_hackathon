import sqlite3
from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
llm = OpenAI(api_key=API_KEY)

user_message_toc_temp = """
Generate an ebook for the topic '{topic}'
1. Introduction to {topic}
.
.
.
13. Conclusion
fill in the dots with the appropriate TOC with an appropriate name, make sure to append these names with the title for proper content generation, make sure to follow the format of the provided TOC and do not generate the heading 'Table of Contents' or any other content apart from TOC
"""

user_message_title_temp = """
Generate an appropriate title of the ebook for the topic '{topic}'
Keep the title crisp and to the point
"""

user_message_content_temp = """
    generate content for this topic '{topic}' in markdown format.
    Note that this content will go into an ebook, so make sure it is relevant and informative and complete within specified tokens only.
    You are free to use any resources available on the internet to generate the content.
    But you are not allowed to provide incomplete information.
    Do not include the heading 'Table of Contents' or any other content apart from the content for the topic.
"""


def return_response(user_message_temp, pass_content, max_tokens=500):
    return llm.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an AI ebook generator, assisting users in creating ebooks."},
            {"role": "user", "content": user_message_temp.format(topic=pass_content)},
        ],
        temperature=0.15,
        max_tokens=max_tokens,
        top_p=1,
    )


# Create an SQLite database connection
conn = sqlite3.connect('ebook_database.db')
cursor = conn.cursor()

# Create a table for TOC
cursor.execute('''
    CREATE TABLE IF NOT EXISTS toc (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        toc_content TEXT
    )
''')

# Prompt user for the topic
user_input = input("Enter the topic for the ebook: ")

# Generate title and TOC
title = return_response(user_message_title_temp, user_input, 50).choices[0].message.content
lines = return_response(user_message_toc_temp, user_input, 150).choices[0].message.content.split("\n")

# Store TOC in the database
toc_content = '\n'.join(lines)
cursor.execute('INSERT INTO toc (title, toc_content) VALUES (?, ?)', (title, toc_content))
conn.commit()

# Iterate through TOC and generate content for each section
counter = 1
for line in lines:
    if line.strip() != "":
        content = return_response(user_message_content_temp, line, 1000).choices[0].message.content

        # Write content to a Markdown file
        with open(f"{counter}.md", "w") as file:
            file.write(content)
            print(f"{counter}.md file created successfully")

        counter += 1

# Close the database connection
conn.close()
