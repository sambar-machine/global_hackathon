<h1 style='color: #3366BB; text-align: center;'>"The Ultimate Mutton Biriyani Recipe Guide"</h1>
<h2 style='text-align: center;'>Table of Contents</h2>
<ul style='list-style: none; margin-top: 16px;'>
  <li style='font-size: 20px; text-decoration: none;'>1. Introduction to Mutton Biriyani recipe guide</li>
  <li style='font-size: 20px; text-decoration: none;'>2. History of Mutton Biriyani</li>
  <li style='font-size: 20px; text-decoration: none;'>3. Essential Ingredients for Mutton Biriyani</li>
  <li style='font-size: 20px; text-decoration: none;'>4. Types of Rice for Mutton Biriyani</li>
  <li style='font-size: 20px; text-decoration: none;'>5. Choosing the Right Cut of Mutton</li>
  <li style='font-size: 20px; text-decoration: none;'>6. Marinating the Mutton</li>
  <li style='font-size: 20px; text-decoration: none;'>7. Preparing the Spice Mix</li>
  <li style='font-size: 20px; text-decoration: none;'>8. Cooking the Rice</li>
  <li style='font-size: 20px; text-decoration: none;'>9. Cooking the Mutton</li>
  <li style='font-size: 20px; text-decoration: none;'>10. Layering the Mutton Biriyani</li>
  <li style='font-size: 20px; text-decoration: none;'>11. Dum Cooking Technique</li>
  <li style='font-size: 20px; text-decoration: none;'>12. Serving and Garnishing Mutton Biriyani</li>
  <li style='font-size: 20px; text-decoration: none;'>13. Conclusion</li>
</ul>
