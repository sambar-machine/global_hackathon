from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)

# Replace the following with your MySQL database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Abhinav@1902',
    'database': 'ebook_db'
}

conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# def create_table():
#     query = """
#     CREATE TABLE IF NOT EXISTS tbl_content (
#         id INT AUTO_INCREMENT PRIMARY KEY,
#         content TEXT NOT NULL,
#         prompt_id
#     )
#     """
#     cursor.execute(query)
#     conn.commit()

@app.route('/submit-form/<prompt>', methods=['GET'])
def submit_form(prompt):
    # create_table()  # Create table if not exists
    return prompt
    # content = data['content']

    # query = "INSERT INTO content (text) VALUES (%s)"
    # cursor.execute(query, (content,))
    # conn.commit()

    # return jsonify({'message': 'Form submitted successfully'})

if __name__ == '__main__':
    app.run()
