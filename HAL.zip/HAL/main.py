from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
llm = OpenAI(api_key=API_KEY)

user_message_toc_temp = """
Generate an ebook for the topic '{topic}'
1. Introduction to {topic}
.
.
.
13. Conclusion
fill in the dots with the appropriate TOC with appropriate name, make sure to append these names with the title for proper content generation, make sure to follow the format of the provided TOC and do not generate the heading 'Table of Contents' or any other content apart from TOC
"""

user_message_title_temp = """
Generate an appropriate title of the ebook for the topic '{topic}'
Keep the title crisp and to the point
"""

user_message_content_temp = """
    generate content for this topic '{topic}' in markdown format.
    Note that this content will go into an ebook, so make sure it is relevant and informative and complete within specified tokens only.
    You are free to use any resources available on the internet to generate the content.
    But you are not allowed to provide incomplete information.
    Do not include the heading 'Table of Contents' or any other content apart from the content for the topic.
"""


def return_response(user_message_temp, pass_content, max_tokens=500):
    return llm.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are an AI ebook generator, assisting users in creating ebooks."},
        {"role": "user", "content": user_message_temp.format(topic=pass_content)},
    ],
    temperature=0.15,
    max_tokens=max_tokens,
    top_p=1,
)
    
user_input = input("Enter the topic for the ebook: ")

title = return_response(user_message_title_temp, user_input, 50).choices[0].message.content
lines = return_response(user_message_toc_temp, user_input, 150).choices[0].message.content.split("\n")

with open("TOC.md", "w") as file:
    file.write(f"<h1 style='color: #3366BB; text-align: center;'>{title}</h1>\n")  
    file.write("<h2 style='text-align: center;'>Table of Contents</h2>\n")  
    file.write("<ul style='list-style: none; margin-top: 16px;'>\n")  
    for line in lines:
        if line != "":
            file.write(f"  <li style='font-size: 20px; text-decoration: none;'>{line}</li>\n")
    file.write('</ul>\n')
    print("TOC.md file created successfully")

#? this part will be removed, TOC will be instead pushed to the database
with open("toc.txt", "w") as file:
    for line in lines:
        if line != "":
            file.write(f"{line}\n")
    print("toc.txt file created successfully\n")


#? Iteration will be performed from the database
file_path = "toc.txt"  
with open(file_path, "r") as file:
    content = file.readlines()

counter = 1

for line in content:
    with open(f"{counter}.md", "w") as file:
        file.write(return_response(user_message_content_temp, line, 1000).choices[0].message.content)
        print(f"{counter}.md file created successfully\n")
    counter += 1
    print(line, end="\n")

